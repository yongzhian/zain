var image_file	    = document.getElementById('image_file');
var image_info      = document.getElementById('image_info');
var image_preview   = document.getElementById('image_preview');

// 监听change事件:
image_file.addEventListener('change', fun_image_preview);

function fun_image_preview(){
	// 检查文件是否选择:
	if(!image_file.value){
		image_info.innerHTML = '没有选择文件';
		return;
	}

	// 获取File引用:
	var file = image_file.files[0];
	//判断文件大小
	var size = file.size;
	if(size > 2*1024*1024){
		alert('文件不能大于2MB!');
		return false;
	}
	// 获取File信息:
	image_info.innerHTML = '文件: ' + file.name + '<br>' + '大小: ' + file.size + '<br>';
	if(file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/jpg'){
		alert('不是有效的图片文件!');
		return;
	}

    // 清除背景图片:
	image_preview.style.backgroundImage = '';
				
	// 读取文件:
	var reader = new FileReader();
	reader.onload = function(event) {
		var data = event.target.result;
		image_preview.style.backgroundImage = 'url(' + data + ')';
	};
	// 以DataURL的形式读取文件:
	reader.readAsDataURL(file);
}

$(function () {
    var ajaxFormOption = {
        type: "post", //提交方式
//        dataType: "json", //数据类型
        url: "/od", //请求url
        success: function (data) { //提交成功的回调函数
            alert(data);
        }
    };

    $("#submit_btn").click(function () {
        $("#image_upload_form").ajaxSubmit(ajaxFormOption);
    });
});


